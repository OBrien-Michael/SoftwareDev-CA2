package library;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LoanTest {

    @Test
    void getMember() {
    }

    @Test
    void setMember() {
    }

    @Test
    void getLibraryItem() {
    }

    @Test
    void setLibraryItem() {
    }

    @Test
    void getDateBorrowed() {
    }

    @Test
    void setDateBorrowed() {
    }

    @Test
    void getDateReturned() {
    }

    @Test
    void setDateReturned() {
    }

    @Test
    void returnItem() {
    }

    @Test
    void compareTo() {
    }

    @Test
    void displayAllDetails() {
    }

    @Test
    void displaySummaryDetails() {
    }

    @Test
    void saveToCSVFile() {
    }
}