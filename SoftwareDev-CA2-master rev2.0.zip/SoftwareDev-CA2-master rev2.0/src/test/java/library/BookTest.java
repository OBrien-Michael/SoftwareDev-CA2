package library;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BookTest {

    @Test
    void getIsbn() {
    }

    @Test
    void setIsbn() {
    }

    @Test
    void testToString() {
    }

    @Test
    void getTitle() {
    }

    @Test
    void setTitle() {
    }

    @Test
    void getAuthor() {
    }

    @Test
    void setAuthor() {
    }

    @Test
    void isAvailability() {
    }

    @Test
    void setAvailability() {
    }

    @Test
    void testToString1() {
    }

    @Test
    void compareTo() {
    }

    @Test
    void displayAllDetails() {
    }

    @Test
    void displaySummaryDetails() {
    }

    @Test
    void saveToCSVFile() {
    }
}