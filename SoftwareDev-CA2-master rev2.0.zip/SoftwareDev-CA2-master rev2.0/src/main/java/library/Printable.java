package library;

public interface Printable {

    public void displayAllDetails();
    public void displaySummaryDetails();

}
