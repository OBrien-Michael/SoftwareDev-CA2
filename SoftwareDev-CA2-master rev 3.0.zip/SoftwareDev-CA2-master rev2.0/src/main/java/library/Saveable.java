package library;

import java.util.ArrayList;

public interface Saveable {
    public ArrayList<String> convertToCommaDelimitedArray();
}
