package library;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DissertationTest {

    @Test
    void getTopic() {
    }

    @Test
    void setTopic() {
    }

    @Test
    void getAbstractText() {
    }

    @Test
    void setAbstractText() {
    }

    @Test
    void getDatePublished() {
    }

    @Test
    void setDatePublished() {
    }

    @Test
    void testToString() {
    }

    @Test
    void getTitle() {
    }

    @Test
    void setTitle() {
    }

    @Test
    void getAuthor() {
    }

    @Test
    void setAuthor() {
    }

    @Test
    void isAvailability() {
    }

    @Test
    void setAvailability() {
    }


    @Test
    void compareTo() {
    }

    @Test
    void displayAllDetails() {
    }

    @Test
    void displaySummaryDetails() {
    }

    @Test
    void saveToCSVFile() {
    }
}