package library;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LibraryUserTest {

    @Test
    void getMemberId() {
    }

    @Test
    void setMemberId() {
    }

    @Test
    void getMemberName() {
    }

    @Test
    void setMemberName() {
    }

    @Test
    void getBorrowedAssets() {
    }

    @Test
    void setBorrowedAssets() {
    }

    @Test
    void testToString() {
    }

    @Test
    void compareTo() {
    }

    @Test
    void displayAllDetails() {
    }

    @Test
    void displaySummaryDetails() {
    }

    @Test
    void saveToCSVFile() {
    }
}