package library;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CatalogueTest {

    @Test
    void getMemberLinkedList() {
    }

    @Test
    void setMemberLinkedList() {
    }

    @Test
    void getAuthorLinkedList() {
    }

    @Test
    void setAuthorLinkedList() {
    }

    @Test
    void getLibraryItemLinkedList() {
    }

    @Test
    void setLibraryItemLinkedList() {
    }

    @Test
    void getLoanLinkedList() {
    }

    @Test
    void setLoanLinkedList() {
    }

    @Test
    void testToString() {
    }
}