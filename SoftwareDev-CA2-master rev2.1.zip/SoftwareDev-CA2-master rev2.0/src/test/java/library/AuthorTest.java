package library;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AuthorTest {

    @Test
    void getAuthorId() {
    }

    @Test
    void setAuthorId() {
    }

    @Test
    void getAuthorName() {
    }

    @Test
    void setAuthorName() {
    }

    @Test
    void getAuthoredBooks() {
    }

    @Test
    void setAuthoredBooks() {
    }

    @Test
    void testToString() {
    }

    @Test
    void compareTo() {
    }

    @Test
    void displayAllDetails() {
    }

    @Test
    void displaySummaryDetails() {
    }

    @Test
    void saveToCSVFile() {
    }
}